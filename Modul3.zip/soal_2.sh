# Install DHCP server di Aldarion
apt-get update
apt-get install isc-dhcp-server -y

echo 'INTERFACESv4="eth0"' > /etc/default/isc-dhcp-server

cat > /etc/dhcp/dhcpd.conf <<EOF

# Subnet untuk Keluarga Manusia (Númenor)
subnet 10.74.1.0 netmask 255.255.255.0 {
    range 10.74.1.6 10.74.1.34;
    range 10.74.1.68 10.74.1.94;
    option routers 10.74.1.1;
    option broadcast-address 10.74.1.255;
    option domain-name-servers 10.74.3.3, 10.74.3.2;
    default-lease-time 600;
    max-lease-time 7200;
}

# Subnet untuk Keluarga Peri (Elf)
subnet 10.74.2.0 netmask 255.255.255.0 {
    range 10.74.2.35 10.74.2.67;
    range 10.74.2.96 10.74.2.121;
    option routers 10.74.2.1;
    option broadcast-address 10.74.2.255;
    option domain-name-servers 10.74.3.3, 10.74.3.2;
    default-lease-time 600;
    max-lease-time 7200;
}

# Subnet untuk jaringan Kurcaci (Relay)
subnet 10.74.3.0 netmask 255.255.255.0 {
    option routers 10.74.3.1;
    option broadcast-address 10.74.3.255;
    option domain-name-servers 10.74.4.2;
}

# Subnet untuk server & database
subnet 10.74.4.0 netmask 255.255.255.0 {
    option routers 10.74.4.1;
    option broadcast-address 10.74.4.255;
    option domain-name-servers 10.74.3.3, 10.74.3.2;
}

# Fixed address untuk Khamul
host Khamul {
    hardware ethernet 02:42:a2:bd:ad:00;
    fixed-address 10.74.3.95;
}
EOF

service isc-dhcp-server restart

# Install DHCP relay di Durin
apt-get install isc-dhcp-relay -y
service isc-dhcp-relay start

cat > /etc/default/isc-dhcp-relay <<EOF
SERVERS="10.74.4.4"
INTERFACES="eth1 eth2 eth3 eth4 eth5"
OPTIONS=""
EOF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.conf
sysctl -p

service isc-dhcp-relay restart