# Erendis
apt-get update && apt-get install bind9 -y

mkdir /etc/bind/zones

service named restart

named-checkconf

named-checkzone k21.com /etc/bind/zones/k21.com.db

service named status

# Amdir
apt-get update && apt-get install bind9 -y

service named restart
