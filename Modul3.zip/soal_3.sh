# Minastir
apt-get update && apt-get install bind9 -y

service named restart